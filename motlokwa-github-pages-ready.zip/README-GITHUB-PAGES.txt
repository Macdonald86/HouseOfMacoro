MOTLOKWA ONE-PAGE E-STORE - GITHUB PAGES READY

Upload the CONTENTS of this folder to your GitHub repository root:

1. index.html
2. assets/motlokwa-crest.png
3. .nojekyll

Important:
- Do not upload only index.html. The assets folder must also be uploaded, otherwise the crest/logo will not show.
- Do not place everything inside a nested folder unless GitHub Pages is configured to publish from that folder.
- In GitHub, go to Settings > Pages.
- Source: Deploy from a branch.
- Branch: main.
- Folder: /root.
- Save, then wait for GitHub Pages to finish deploying.

GitHub Pages is static hosting. The page can show products and create WhatsApp order messages, but real online payments, shared admin database, and automatic order storage require a real backend or services like PayFast/Yoco/Ozow + Supabase/Firebase/Render/Vercel.
